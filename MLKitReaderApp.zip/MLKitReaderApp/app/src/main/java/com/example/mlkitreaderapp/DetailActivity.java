package com.example.mlkitreaderapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;

public class DetailActivity extends AppCompatActivity {

    private TextView detailReaderText, detailResultText;
    private ImageView detailImageView;
    private Button editBtn, deleteBtn, cancelBtn;

    private String id, filename, reader, text;
    private DatabaseReference databaseReference;
    private byte[] imageBytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        detailReaderText = findViewById(R.id.detailReaderText);
        detailResultText = findViewById(R.id.detailResultText);
        detailImageView = findViewById(R.id.detailImageView);
        editBtn = findViewById(R.id.editBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        cancelBtn = findViewById(R.id.cancelBtn);

        databaseReference = FirebaseDatabase
                .getInstance("https://mlkitreaderapp-45e69-default-rtdb.firebaseio.com/")
                .getReference("items");

        id = getIntent().getStringExtra("id");
        filename = getIntent().getStringExtra("filename");
        reader = getIntent().getStringExtra("reader");
        text = getIntent().getStringExtra("text");

        detailReaderText.setText(reader);
        detailResultText.setText(text);

        loadImage();

        editBtn.setOnClickListener(v -> openEditScreen());
        deleteBtn.setOnClickListener(v -> deleteItem());
        cancelBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DetailActivity.this, ListActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void loadImage() {
        try {
            FileInputStream fis = openFileInput(filename);
            Bitmap bitmap = BitmapFactory.decodeStream(fis);
            detailImageView.setImageBitmap(bitmap);

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            imageBytes = stream.toByteArray();

            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openEditScreen() {
        Intent intent = new Intent(DetailActivity.this, EditSaveActivity.class);
        intent.putExtra("id", id);
        intent.putExtra("filename", filename);
        intent.putExtra("reader", reader);
        intent.putExtra("result", text);
        intent.putExtra("isNew", false);
        intent.putExtra("imageBytes", imageBytes);
        startActivity(intent);
    }

    private void deleteItem() {
        databaseReference.child(id).removeValue().addOnSuccessListener(unused -> {
            Intent intent = new Intent(DetailActivity.this, ListActivity.class);
            startActivity(intent);
            finish();
        });
    }
}