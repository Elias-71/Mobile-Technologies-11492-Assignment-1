package com.example.mlkitreaderapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.FileOutputStream;

public class EditSaveActivity extends AppCompatActivity {

    private EditText editReaderTitle;
    private EditText editResultText;
    private ImageView editImageView;
    private Button saveBtn;

    private String id;
    private String filename;
    private String reader;
    private String result;
    private boolean isNew;
    private byte[] imageBytes;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_save);

        editReaderTitle = findViewById(R.id.editReaderTitle);
        editResultText = findViewById(R.id.editResultText);
        editImageView = findViewById(R.id.editImageView);
        saveBtn = findViewById(R.id.saveBtn);

        databaseReference = FirebaseDatabase
                .getInstance("https://mlkitreaderapp-45e69-default-rtdb.firebaseio.com/")
                .getReference("items");

        id = getIntent().getStringExtra("id");
        filename = getIntent().getStringExtra("filename");
        reader = getIntent().getStringExtra("reader");
        result = getIntent().getStringExtra("result");
        isNew = getIntent().getBooleanExtra("isNew", true);
        imageBytes = getIntent().getByteArrayExtra("imageBytes");

        if (reader != null) {
            editReaderTitle.setText(reader);
        }

        if (result != null) {
            editResultText.setText(result);
        }

        if (imageBytes != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            editImageView.setImageBitmap(bitmap);
        }

        saveBtn.setOnClickListener(v -> saveData());
    }

    private void saveData() {
        String updatedReader = editReaderTitle.getText().toString().trim();
        String updatedResult = editResultText.getText().toString().trim();

        if (updatedReader.isEmpty() || updatedResult.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (imageBytes == null) {
            Toast.makeText(this, "No image to save", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isNew) {
            saveNewItem(updatedReader, updatedResult);
        } else {
            updateExistingItem(updatedReader, updatedResult);
        }
    }

    private void saveNewItem(String updatedReader, String updatedResult) {
        String uniqueId = String.valueOf(System.currentTimeMillis());
        String newFilename = uniqueId + ".png";

        boolean imageSaved = saveImageToInternalStorage(newFilename);

        if (!imageSaved) {
            Toast.makeText(this, "Image could not be saved", Toast.LENGTH_SHORT).show();
            return;
        }

        AnalyzedItem item = new AnalyzedItem(uniqueId, newFilename, updatedReader, updatedResult);

        databaseReference.child(uniqueId).setValue(item)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Saved successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(EditSaveActivity.this, ListActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Firebase save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                });
    }

    private void updateExistingItem(String updatedReader, String updatedResult) {
        AnalyzedItem item = new AnalyzedItem(id, filename, updatedReader, updatedResult);

        databaseReference.child(id).setValue(item)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Updated successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(EditSaveActivity.this, ListActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                });
    }

    private boolean saveImageToInternalStorage(String filenameToSave) {
        try {
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            FileOutputStream fos = openFileOutput(filenameToSave, MODE_PRIVATE);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}