package com.example.mlkitreaderapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    private ListView listViewItems;
    private Button addBtn;

    private ArrayList<AnalyzedItem> items;
    private com.example.mlkitreaderapp.AnalyzedItemAdapter adapter;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listViewItems = findViewById(R.id.listViewItems);
        addBtn = findViewById(R.id.addBtn);

        items = new ArrayList<>();
        adapter = new com.example.mlkitreaderapp.AnalyzedItemAdapter(this, items);
        listViewItems.setAdapter(adapter);

        databaseReference = FirebaseDatabase
                .getInstance("https://mlkitreaderapp-45e69-default-rtdb.firebaseio.com/")
                .getReference("items");

        loadItems();

        addBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ListActivity.this, MainActivity.class);
            startActivity(intent);
        });

        listViewItems.setOnItemClickListener((parent, view, position, id) -> {
            AnalyzedItem selectedItem = items.get(position);

            Intent intent = new Intent(ListActivity.this, DetailActivity.class);
            intent.putExtra("id", selectedItem.getId());
            intent.putExtra("filename", selectedItem.getFilename());
            intent.putExtra("reader", selectedItem.getReader());
            intent.putExtra("text", selectedItem.getText());
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    private void loadItems() {
        databaseReference.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                items.clear();

                for (DataSnapshot snapshot : task.getResult().getChildren()) {
                    AnalyzedItem item = snapshot.getValue(AnalyzedItem.class);
                    if (item != null) {
                        items.add(item);
                    }
                }

                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Could not load data from Firebase", Toast.LENGTH_SHORT).show();
            }
        });
    }
}