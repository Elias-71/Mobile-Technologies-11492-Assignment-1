package com.example.mlkitreaderapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;

public class ReaderActivity extends AppCompatActivity {

    private TextView titleReader, instructionText;
    private ImageView selectedImage;
    private Button openCameraBtn, loadImageBtn, editResultBtn;

    private String type;
    private String resultText = "";

    private ActivityResultLauncher<Void> cameraLauncher;
    private ActivityResultLauncher<String> galleryLauncher;

    private Bitmap currentBitmap;
    private Uri currentImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reader);

        titleReader = findViewById(R.id.titleReader);
        instructionText = findViewById(R.id.instructionText);
        selectedImage = findViewById(R.id.selectedImage);
        openCameraBtn = findViewById(R.id.openCameraBtn);
        loadImageBtn = findViewById(R.id.loadImageBtn);
        editResultBtn = findViewById(R.id.editResultBtn);

        type = getIntent().getStringExtra("type");

        if (type != null) {
            if (type.equals("barcode")) {
                titleReader.setText("Barcode Reader");
                selectedImage.setImageResource(R.drawable.barcode);
            } else if (type.equals("content")) {
                titleReader.setText("Content Reader");
                selectedImage.setImageResource(R.drawable.content);
            } else if (type.equals("text")) {
                titleReader.setText("Text Reader");
                selectedImage.setImageResource(R.drawable.text);
            }
        }

        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicturePreview(),
                bitmap -> {
                    if (bitmap != null) {
                        currentBitmap = bitmap;
                        currentImageUri = null;
                        selectedImage.setImageBitmap(bitmap);
                        runMLKitOnBitmap(bitmap);
                    } else {
                        Toast.makeText(this, "No photo was captured", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        currentImageUri = uri;
                        try {
                            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                            currentBitmap = bitmap;
                            selectedImage.setImageBitmap(bitmap);
                            runMLKitOnBitmap(bitmap);
                        } catch (IOException e) {
                            Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                }
        );

        openCameraBtn.setOnClickListener(v -> cameraLauncher.launch(null));
        loadImageBtn.setOnClickListener(v -> galleryLauncher.launch("image/*"));

        editResultBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ReaderActivity.this, EditSaveActivity.class);
            intent.putExtra("reader", titleReader.getText().toString());
            intent.putExtra("result", resultText);
            intent.putExtra("isNew", true);

            if (currentBitmap != null) {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                currentBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] imageBytes = stream.toByteArray();
                intent.putExtra("imageBytes", imageBytes);
            }

            startActivity(intent);
        });
    }

    private void runMLKitOnBitmap(Bitmap bitmap) {
        InputImage inputImage = InputImage.fromBitmap(bitmap, 0);

        if ("barcode".equals(type)) {
            scanBarcode(inputImage);
        } else if ("content".equals(type)) {
            labelImage(inputImage);
        } else if ("text".equals(type)) {
            recognizeText(inputImage);
        }
    }

    private void scanBarcode(InputImage inputImage) {
        BarcodeScanner scanner = BarcodeScanning.getClient();

        scanner.process(inputImage)
                .addOnSuccessListener(barcodes -> {
                    if (barcodes.isEmpty()) {
                        resultText = "Detected barcode: No barcode found";
                    } else {
                        StringBuilder builder = new StringBuilder();
                        builder.append("Detected barcode: ");

                        for (int i = 0; i < barcodes.size(); i++) {
                            String value = barcodes.get(i).getRawValue();
                            if (value != null) {
                                if (i > 0) builder.append("\n");
                                builder.append(value);
                            }
                        }

                        resultText = builder.toString();
                    }

                    showResultState();
                })
                .addOnFailureListener(e -> {
                    resultText = "Detected barcode: Error reading barcode";
                    showResultState();
                });
    }

    private void labelImage(InputImage inputImage) {
        ImageLabelerOptions options =
                new ImageLabelerOptions.Builder()
                        .setConfidenceThreshold(0.5f)
                        .build();

        ImageLabeling.getClient(options)
                .process(inputImage)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        resultText = "Recognised image content: No content found";
                    } else {
                        StringBuilder builder = new StringBuilder();
                        builder.append("Recognised image content:\n");

                        for (int i = 0; i < labels.size(); i++) {
                            ImageLabel label = labels.get(i);
                            int number = i + 1;
                            builder.append(number)
                                    .append(". ")
                                    .append(label.getText())
                                    .append(" (")
                                    .append(String.format("%.2f", label.getConfidence() * 100))
                                    .append("% confidence)");

                            if (i < labels.size() - 1) {
                                builder.append("\n");
                            }
                        }

                        resultText = builder.toString();
                    }

                    showResultState();
                })
                .addOnFailureListener(e -> {
                    resultText = "Recognised image content: Error reading content";
                    showResultState();
                });
    }

    private void recognizeText(InputImage inputImage) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(inputImage)
                .addOnSuccessListener(visionText -> {
                    String extracted = visionText.getText().trim();

                    if (extracted.isEmpty()) {
                        resultText = "Extracted text: No text found";
                    } else {
                        resultText = "Extracted text:\n" + extracted;
                    }

                    showResultState();
                })
                .addOnFailureListener(e -> {
                    resultText = "Extracted text: Error reading text";
                    showResultState();
                });
    }

    private void showResultState() {
        instructionText.setText(resultText);
        editResultBtn.setVisibility(Button.VISIBLE);
    }
}