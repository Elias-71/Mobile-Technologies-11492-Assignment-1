package com.example.mlkitreaderapp;

public class AnalyzedItem {
    private String id;
    private String filename;
    private String reader;
    private String text;

    public AnalyzedItem() {
    }

    public AnalyzedItem(String id, String filename, String reader, String text) {
        this.id = id;
        this.filename = filename;
        this.reader = reader;
        this.text = text;
    }

    public String getId() {
        return id;
    }

    public String getFilename() {
        return filename;
    }

    public String getReader() {
        return reader;
    }

    public String getText() {
        return text;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public void setText(String text) {
        this.text = text;
    }
}