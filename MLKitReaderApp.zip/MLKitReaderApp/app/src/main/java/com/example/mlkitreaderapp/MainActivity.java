package com.example.mlkitreaderapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageView barcodeImage, contentImage, textImage;
    Button listButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        barcodeImage = findViewById(R.id.barcodeImage);
        contentImage = findViewById(R.id.contentImage);
        textImage = findViewById(R.id.textImage);
        listButton = findViewById(R.id.listButton);

        // Open ReaderActivity with type
        barcodeImage.setOnClickListener(v -> openReader("barcode"));
        contentImage.setOnClickListener(v -> openReader("content"));
        textImage.setOnClickListener(v -> openReader("text"));

        // Open ListActivity
        listButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            startActivity(intent);
        });
    }

    private void openReader(String type) {
        Intent intent = new Intent(MainActivity.this, ReaderActivity.class);
        intent.putExtra("type", type);
        startActivity(intent);
    }
}