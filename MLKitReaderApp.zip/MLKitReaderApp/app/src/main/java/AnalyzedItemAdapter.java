package com.example.mlkitreaderapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.FileInputStream;
import java.util.ArrayList;

public class AnalyzedItemAdapter extends ArrayAdapter<AnalyzedItem> {

    private final Context context;
    private final ArrayList<AnalyzedItem> items;

    public AnalyzedItemAdapter(Context context, ArrayList<AnalyzedItem> items) {
        super(context, 0, items);
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        AnalyzedItem currentItem = items.get(position);

        ImageView itemImage = listItemView.findViewById(R.id.itemImage);
        TextView itemText = listItemView.findViewById(R.id.itemText);

        itemText.setText(currentItem.getReader());

        try {
            FileInputStream fis = context.openFileInput(currentItem.getFilename());
            Bitmap bitmap = BitmapFactory.decodeStream(fis);
            itemImage.setImageBitmap(bitmap);
            fis.close();
        } catch (Exception e) {
            itemImage.setImageResource(R.drawable.barcode);
        }

        if (position % 2 == 0) {
            listItemView.setBackgroundColor(0xFFFFFFFF); // white
        } else {
            listItemView.setBackgroundColor(0xFFEFEFEF); // grey
        }

        return listItemView;
    }
}